import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Contato } from '../classes/atributos';

@Component({
  selector: 'app-pessoa',
  templateUrl: './pessoa.component.html',
  styleUrls: ['./pessoa.component.css']
})
export class PessoaComponent implements OnInit {

  pessoas: Array<Contato>= [];

  pessoasForm = new FormGroup({
    nome: new FormControl(''), 
    idade: new FormControl(''), 
    telefone: new FormControl(''), 
    email: new FormControl(''), 
    localizacao: new FormGroup({
      endereco: new FormControl(''),
      estado: new FormControl(''),
      cep: new FormControl('')
    })
  })

  IncluirPessoa(){
    let pessoa: Contato = new Contato(); 
    // console.log(this.pessoasForm.value['telefone'])
    pessoa.nome = this.pessoasForm.value['nome']; 
    pessoa.idade = this.pessoasForm.value['idade']; 
    pessoa.telefone = this.pessoasForm.value['telefone']
    pessoa.email = this.pessoasForm.value['email']
    pessoa.localizacao = this.pessoasForm.value['localizacao']
    this.pessoas.push(pessoa);
  }
  constructor() {}

  if(pessoa = this.pessoas){
    window.alert("dfdfds")  
  }

  ngOnInit(): void {
    // let pessoa = new Contato();
    // pessoa.email = 'felipe@quickfast.com';
    // this.pessoas.push(pessoa);
  }


}
